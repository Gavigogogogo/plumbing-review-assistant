PREFERRED PLUMBING — GOOGLE REVIEW ASSISTANT
================================================

UPDATED VERSION
- Review drafts now vary on each generation: different openers, phrasing, ordering,
  transitions, and closing sentences.
- Drafts can be longer when customers select multiple details or add their own note.
- It only uses selected experience details; it does not force a star rating.
- Customer can edit and copy the draft before posting.

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Replace PASTE_YOUR_GOOGLE_REVIEW_LINK_HERE with the company's direct Google review URL.
   Find it in Google Business Profile → Ask for reviews → Copy link.
3. Upload index.html to a static host or the existing business website.
4. Point the QR code to the public website URL.

NOTE
The site files are built, but not hosted at a public URL. Opening HTML in an iPhone file
preview may not run JavaScript; use a real browser or publish it to a host to test buttons.
Google review drafts should reflect the customer's genuine experience. Don't offer incentives,
pressure customers, or ask only for positive reviews. The page doesn't store customer answers.
